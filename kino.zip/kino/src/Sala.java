import java.util.ArrayList;
import java.util.List;

class Sala {
    private int cisloSalu;
    private int pocetRad;
    private int pocetKreselVRade;
    private List<Film> filmy;
    private boolean podpora3D;

    public Sala(int cisloSalu, int pocetRad, int pocetKreselVRade, boolean podpora3D) {
        this.cisloSalu = cisloSalu;
        this.pocetRad = pocetRad;
        this.pocetKreselVRade = pocetKreselVRade;
        this.filmy = new ArrayList<>();
        this.podpora3D = podpora3D;
    }

    public int getCisloSalu() {
        return cisloSalu;
    }

    public int getPocetRad() {
        return pocetRad;
    }

    public int getPocetKreselVRade() {
        return pocetKreselVRade;
    }

    public List<Film> getFilmy() {
        return filmy;
    }

    public boolean isPodpora3D() {
        return podpora3D;
    }

    public void pridatFilm(Film film) {
        filmy.add(film);
    }
}
